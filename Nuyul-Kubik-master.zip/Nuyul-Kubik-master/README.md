
# Nuyul-Kubik
Pertama buka dengan nano kubik.php 
Lalu ganti token,tk,uuid,adroidid,
